import main

from sklearn.preprocessing import StandardScaler, LabelEncoder



import pandas as pd
data=pd.read_csv('F:\Gouthami\Modified04.csv',names = ["age", "sex", "bmi", "bp", "chol", "sugar", "hr", "excercise", "class"]);
for column in data.columns:
    if data[column].dtype == type(object):
        le = LabelEncoder()
        data[column] = le.fit_transform(data[column])
X = data.drop('age',axis=1)
y = data['class']

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y)

scaler = StandardScaler()
# Fit only to the training data
scaler.fit(X_train)
StandardScaler(copy=True, with_mean=True, with_std=True)
# Now apply the transformations to the data:
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)


#training
from sklearn.neural_network import MLPClassifier

mlp = MLPClassifier(hidden_layer_sizes=(50,50,50),max_iter=700)
mlp.fit(X_train,y_train)


predictions = mlp.predict(X_test)
def prediction(age,sex,bmi,bp,cholesterol,blood_sugar,heart_rate,exercise):
    value=mlp.predict([[age,sex,bmi,bp,cholesterol,blood_sugar,heart_rate,exercise]])
    #value=mlp.predict([[44,1,22,120,263,120,173,0]])
    print value
    from sklearn.metrics import classification_report, confusion_matrix
    print(confusion_matrix(y_test, predictions))
    print(classification_report(y_test, predictions))
    return value















