drop table if exists users;
    create table users (
    id integer primary key autoincrement,
    username text not null,
    password text not null
);

drop table if exists patient_details;
    CREATE TABLE `patient_details` (
	`patient_id`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
	`age`	INTEGER NOT NULL,
	`Sex`	TEXT NOT NULL,
	`chest_pain`	TEXT NOT NULL,
	`resting_bp`	INTEGER NOT NULL,
	`serum_cholestrol`	INTEGER NOT NULL,
	`fasting_sugar`	INTEGER NOT NULL,
	`resting_ecg_results`	TEXT NOT NULL,
	`max_heart_rate`	INTEGER NOT NULL,
	`exercise_angina`	TEXT NOT NULL,
	`st_depression_induced`	INTEGER NOT NULL,
	`slope_st_segment`	TEXT NOT NULL,
	`no_major_vessels`	INTEGER NOT NULL,
	`thalium_heart_scan`	TEXT NOT NULL
);







